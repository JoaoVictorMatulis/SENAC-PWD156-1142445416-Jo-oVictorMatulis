import {Link} from 'react-router-dom'
import './style.css'

function Header(){
    return(
        <header>
            Empresa
            <div>
                <Link to = "/"> Home</Link>
                <Link to = "/cadastro">Cadastro</Link>
                <Link to = "/contacorrente">Conta Corrente</Link>
                <Link to = "/financiamento">Financiamento</Link>
                <Link to = "/sobrenos">Sobre Nós</Link>
            </div>
        </header>
    )
}
export default Header;