import './index.css'
function SobreNos(){
    return(
        <body class = "c">
            <div>
                <b1>
                Scott Braden Cawthon (nascido em 4 de junho de 1978) é um ex-desenvolvedor e escritor americano de videogames. Ele é o criador da franquia de mídia Five Nights at Freddy's, que começou com o desenvolvimento do jogo de terror de sobrevivência homônimo em 2014. Lançado de forma independente, o jogo alcançou popularidade e obteve seguidores cult. Cawthon desenvolveu 10 jogos na série principal de 2014 até sua aposentadoria em 2021, além de três spin-offs. Ele também escreveu várias histórias baseadas em Five Nights at Freddy's, incluindo o romance The Silver Eyes (2015).
                </b1>
            </div>
        </body>

    )
}
export default SobreNos;