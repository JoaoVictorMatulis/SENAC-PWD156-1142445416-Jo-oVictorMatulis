import './index.css'
function Cadcli(){
    return(
        <body class="bode">
            <div>
                <h1>Cadastro do Cliente</h1>
                <form>
                    <label>
                    Nome: <input type = "text" /><br/>
                    Endereço: <input type = "text"/><br/>
                    CPF: <input type = "text" /><br/>
                    </label>
                </form>
            </div>
            <button>Cadastro</button>
        </body>
    );
}
export default Cadcli;