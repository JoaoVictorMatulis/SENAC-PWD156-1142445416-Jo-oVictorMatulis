import './index.css'
function Home(){
    return(
        <body class = "body">
            <div>
                <h1>
                    Página Home
                </h1>
            </div>
        </body>

    )
}
export default Home;