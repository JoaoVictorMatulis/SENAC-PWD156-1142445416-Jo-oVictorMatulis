/** - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * SENAC - TADS - Programacao Web *
 * ADO #02 Trabalhando As Rotas e LINKS *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*
 * Nome : João Victor Matulis *
 * - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

import RouterApp from "./routes";
function App() {
  return (
    <RouterApp/>
  );
}

export default App;
